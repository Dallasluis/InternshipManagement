using InternshipManagement.Application.Interfaces;
using System;
using System.Text;
using UglyToad.PdfPig;

namespace InternshipManagement.Infrastructure.Documents
{
    /// <summary>
    /// Reads the text layer of a PDF with PdfPig (pure .NET, nothing is written to disk).
    /// Image-only (scanned) PDFs have no text layer and come back (almost) empty; the caller handles that.
    /// </summary>
    public sealed class PdfPigTextExtractor : IPdfTextExtractor
    {
        public string ExtractText(byte[] pdf, int maxPages)
        {
            try
            {
                using var document = PdfDocument.Open(pdf);

                var sb = new StringBuilder();
                var pages = 0;
                foreach (var page in document.GetPages())
                {
                    if (pages++ >= maxPages) break;
                    sb.AppendLine(page.Text);
                }

                return sb.ToString();
            }
            catch (Exception ex)   // corrupt, encrypted, truncated or not a PDF at all
            {
                throw new PdfUnreadableException("The PDF could not be read.", ex);
            }
        }
    }
}
