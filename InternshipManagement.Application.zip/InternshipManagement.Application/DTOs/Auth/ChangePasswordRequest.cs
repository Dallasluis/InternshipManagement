namespace InternshipManagement.Application.DTOs.Auth
{
    public class ChangePasswordRequest
    {
        public string CurrentPassword { get; set; } = string.Empty;
        public string NewPassword { get; set; } = string.Empty;
        public string? TwoFactorCode { get; set; }
    }
}
