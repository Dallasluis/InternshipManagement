using System;

namespace InternshipManagement.Application.DTOs.Admin
{
    public class ReportListResponse
    {
        public int Id { get; set; }
        public string Type { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string InternshipTitle { get; set; } = string.Empty;
        public string ReporterName { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public string? AdminResponse { get; set; }
    }

    public class ReportSummaryResponse
    {
        public int Id { get; set; }
        public string Type { get; set; } = string.Empty;
        public string InternshipTitle { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }

    public class ResolveReportRequest
    {
        public string Response { get; set; } = string.Empty;
        public bool Resolved { get; set; }
        public string? Status { get; set; }
        public bool FraudUpheld { get; set; }
    }
}
