﻿namespace InternshipManagement.Domain.Enums
{
    public enum InternshipStatus
    {
        Draft,
        Published,
        Closed,
        Filled
    }

    // Additional enums needed for the system
    public enum CompanyVerificationStatus
    {
        Unverified = 0,
        Pending = Unverified,
        PendingReview = 1,
        UnderReview = PendingReview,
        Verified = 2,
        Rejected = 3,
        Suspended = 4,
        MoreInformationRequested = 5,
        ReverificationRequired = 6
    }

    public enum ModerationStatus
    {
        Pending,
        Approved,
        Rejected,
        Flagged,
        Removed
    }

    public enum InternshipType
    {
        FullTime,
        PartTime,
        Summer,
        Winter,
        YearRound,
        Flexible
    }

    public enum InternshipWorkArrangement
    {
        OnSite,
        Remote,
        Hybrid
    }

    public enum InternshipDuration
    {
        LessThan3Months,
        ThreeToSixMonths,
        SixToTwelveMonths,
        MoreThanTwelveMonths
    }

    // For reporting (MVP)
    public enum ReportType
    {
        Fraud,
        Scam,
        MisleadingInformation,
        InappropriateContent,
        Harassment,
        Discrimination,
        Other
    }

    public enum ReportStatus
    {
        Pending,
        UnderInvestigation,
        Resolved,
        Dismissed
    }

    // For subscription (placeholder for MVP)
    public enum SubscriptionStatus
    {
        Inactive,
        Active,
        Expired,
        Cancelled
    }

    public enum PlacementStatus
    {
        Pending,
        Active,
        Extended,
        Completed,
        Terminated
    }

    public enum ExtensionStatus
    {
        Proposed,
        Accepted,
        Rejected,
        Cancelled
    }

    public enum WithdrawalStatus
    {
        Requested,
        Approved,
        Rejected,
        Disputed
    }

    public enum ProgressReportStatus
    {
        Submitted,
        Reviewed
    }
}
